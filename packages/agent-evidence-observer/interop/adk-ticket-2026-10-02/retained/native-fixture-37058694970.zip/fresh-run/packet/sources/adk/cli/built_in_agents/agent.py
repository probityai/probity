# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Agent Builder Assistant instance for ADK web testing."""

from __future__ import annotations

from .adk_agent_builder_assistant import AgentBuilderAssistant

# Create the agent instance using the factory
# The root_agent variable is what ADK looks for when loading agents
root_agent = AgentBuilderAssistant.create_agent()
