# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from collections.abc import Awaitable
import importlib
import inspect
from typing import Callable
from typing import cast
from typing import Optional

from typing_extensions import override

from .eval_case import ConversationScenario
from .eval_case import Invocation
from .eval_metrics import EvalMetric
from .evaluator import EvaluationResult
from .evaluator import Evaluator


def _get_metric_function(
    custom_function_path: str,
) -> Callable[
    [
        EvalMetric,
        list[Invocation],
        Optional[list[Invocation]],
        Optional[ConversationScenario],
    ],
    EvaluationResult | Awaitable[EvaluationResult],
]:
  """Returns the custom metric function from the given path."""
  try:
    module_name, function_name = custom_function_path.rsplit(".", 1)
    module = importlib.import_module(module_name)
    metric_function = getattr(module, function_name)
    if not callable(metric_function):
      raise TypeError(
          f"Custom metric {custom_function_path} does not refer to a callable."
      )
    return cast(
        Callable[
            [
                EvalMetric,
                list[Invocation],
                Optional[list[Invocation]],
                Optional[ConversationScenario],
            ],
            EvaluationResult | Awaitable[EvaluationResult],
        ],
        metric_function,
    )
  except (ImportError, AttributeError, ValueError) as e:
    raise ImportError(
        f"Could not import custom metric function from {custom_function_path}"
    ) from e


class _CustomMetricEvaluator(Evaluator):
  """Evaluator for custom metrics."""

  def __init__(self, eval_metric: EvalMetric, custom_function_path: str):
    self._eval_metric = eval_metric
    self._metric_function = _get_metric_function(custom_function_path)

  @override
  async def evaluate_invocations(
      self,
      actual_invocations: list[Invocation],
      expected_invocations: Optional[list[Invocation]] = None,
      conversation_scenario: Optional[ConversationScenario] = None,
  ) -> EvaluationResult:
    eval_metric = self._eval_metric.model_copy(deep=True)
    eval_metric.threshold = None
    eval_result = self._metric_function(
        eval_metric,
        actual_invocations,
        expected_invocations,
        conversation_scenario,
    )
    if inspect.isawaitable(eval_result):
      return await eval_result
    return eval_result
