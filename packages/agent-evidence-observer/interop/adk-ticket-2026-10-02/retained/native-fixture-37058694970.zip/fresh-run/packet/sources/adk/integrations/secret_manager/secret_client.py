# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import json
from typing import Optional

from google.api_core.gapic_v1 import client_info
from google.auth import default as default_service_credential
from google.cloud import secretmanager
from google.oauth2 import credentials as user_credentials
from google.oauth2 import service_account

from ... import version
from ...utils import _mtls_utils

USER_AGENT = f"google-adk/{version.__version__}"

_DEFAULT_REGIONAL_ENDPOINT_TEMPLATE = (
    "secretmanager.{location}.rep.googleapis.com"
)
_DEFAULT_MTLS_REGIONAL_ENDPOINT_TEMPLATE = (
    "secretmanager.{location}.rep.mtls.googleapis.com"
)


class SecretManagerClient:
  """A client for interacting with Google Cloud Secret Manager.

  This class provides a simplified interface for retrieving secrets from
  Secret Manager, handling authentication using a service account JSON
  keyfile (passed as a string) or a preexisting authorization token. If
  neither is provided, it falls back to Application Default Credentials.

  Attributes:
      _credentials:  Google Cloud credentials object (ServiceAccountCredentials
        or Credentials).
      _client: Secret Manager client instance.
  """

  def __init__(
      self,
      service_account_json: Optional[str] = None,
      auth_token: Optional[str] = None,
      location: Optional[str] = None,
  ):
    """Initializes the SecretManagerClient.

    Credentials are resolved in priority order: `service_account_json`, then
    `auth_token`, then Application Default Credentials when neither is
    provided.

    Args:
        service_account_json:  The content of a service account JSON keyfile (as
          a string), not the file path.  Must be valid JSON.
        auth_token: An existing Google Cloud authorization token.
        location: The Google Cloud location (region) to use for the Secret
          Manager service. If not provided, the global endpoint is used.

    Raises:
        ValueError: If both `service_account_json` and `auth_token` are
            provided, if `service_account_json` is not valid JSON, or if
            neither is provided and Application Default Credentials cannot be
            resolved.
        google.auth.exceptions.GoogleAuthError: If authentication fails.
    """
    if service_account_json and auth_token:
      raise ValueError(
          "Must provide either 'service_account_json' or 'auth_token', not"
          " both."
      )

    if service_account_json:
      try:
        credentials = service_account.Credentials.from_service_account_info(
            json.loads(service_account_json)
        )
      except json.JSONDecodeError as e:
        raise ValueError(f"Invalid service account JSON: {e}") from e
    elif auth_token:
      credentials = user_credentials.Credentials(token=auth_token)
    else:
      try:
        credentials, _ = default_service_credential(
            scopes=["https://www.googleapis.com/auth/cloud-platform"]
        )
      except Exception as e:
        raise ValueError(
            "'service_account_json' or 'auth_token' are both missing, and"
            f" error occurred while trying to use default credentials: {e}"
        ) from e

    if not credentials:
      raise ValueError(
          "Must provide either 'service_account_json' or 'auth_token', not both"
          " or neither."
      )

    self._credentials = credentials

    client_options = None
    if location:
      client_options = {
          "api_endpoint": _mtls_utils.get_api_endpoint(
              location,
              _DEFAULT_REGIONAL_ENDPOINT_TEMPLATE,
              _DEFAULT_MTLS_REGIONAL_ENDPOINT_TEMPLATE,
          )
      }

    self._client = secretmanager.SecretManagerServiceClient(
        credentials=self._credentials,
        client_options=client_options,
        client_info=client_info.ClientInfo(user_agent=USER_AGENT),
    )

  def get_secret(self, resource_name: str) -> str:
    """Retrieves a secret from Google Cloud Secret Manager.

    Args:
        resource_name: The full resource name of the secret, in the format
          "projects/*/secrets/*/versions/*".  Usually you want the "latest"
          version, e.g.,
          "projects/my-project/secrets/my-secret/versions/latest".

    Returns:
        The secret payload as a string.

    Raises:
        google.api_core.exceptions.GoogleAPIError: If the Secret Manager API
            returns an error (e.g., secret not found, permission denied).
        Exception: For other unexpected errors.
    """
    try:
      response = self._client.access_secret_version(name=resource_name)
      return response.payload.data.decode("UTF-8")
    except Exception as e:
      raise e  # Re-raise the exception to allow for handling by the caller
      # Consider logging the exception here before re-raising.
