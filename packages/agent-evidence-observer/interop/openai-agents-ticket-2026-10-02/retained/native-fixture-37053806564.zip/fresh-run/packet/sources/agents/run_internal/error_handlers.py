from __future__ import annotations

import inspect
import json
from typing import Any, Literal

from openai.types.responses import ResponseOutputMessage, ResponseOutputText

from ..agent import Agent
from ..agent_output import _WRAPPER_DICT_KEY, AgentOutputSchema
from ..exceptions import (
    InputGuardrailTripwireTriggered,
    MaxTurnsExceeded,
    ModelBehaviorError,
    ModelRefusalError,
    OutputGuardrailTripwireTriggered,
    UserError,
)
from ..items import (
    ItemHelpers,
    MessageOutputItem,
    ModelResponse,
    RunItem,
    TResponseInputItem,
)
from ..logger import logger
from ..models.fake_id import FAKE_RESPONSES_ID
from ..run_context import RunContextWrapper, TContext
from ..run_error_handlers import (
    RunErrorData,
    RunErrorHandlerInput,
    RunErrorHandlerResult,
    RunErrorHandlers,
)
from ..tracing import Span, SpanError
from ..util import _error_tracing
from ..util._error_tracing import REDACTED_TRACE_ERROR_MESSAGE
from .items import ReasoningItemIdPolicy, run_item_to_input_item
from .turn_preparation import get_output_schema

RunErrorHandlerKind = Literal["max_turns", "model_refusal", "invalid_final_output"]

GENERIC_AGENT_ERROR_MESSAGE = "Error in agent run"
UNFORMATTABLE_TRACE_ERROR_MESSAGE = "Error details are unavailable."


def _is_generic_agent_error(exc: BaseException) -> bool:
    """Return whether a failed run still needs the generic agent-span error.

    Only ``Exception`` is eligible: the non-streaming handler also catches ``BaseException``, but
    cancellation is not an agent failure and the streamed path never marks it. Failures that
    already write their own agent-span error, or that a dedicated child span reports, are excluded
    so the span keeps the more specific diagnosis.
    """
    if not isinstance(exc, Exception):
        return False
    return not isinstance(
        exc,
        ModelBehaviorError | InputGuardrailTripwireTriggered | OutputGuardrailTripwireTriggered,
    )


def _format_agent_error_detail(exc: BaseException) -> str:
    """Stringify an exception for tracing without ever raising.

    A custom exception whose ``__str__`` raises must not replace the exception the run is
    propagating, so the formatting failure is swallowed and reported as a placeholder.
    """
    try:
        return str(exc)
    except BaseException:
        return UNFORMATTABLE_TRACE_ERROR_MESSAGE


def attach_generic_agent_error(
    span: Span[Any] | None,
    exc: BaseException,
    *,
    trace_include_sensitive_data: bool,
) -> None:
    """Mark the agent span of a failed run with the generic ``Error in agent run`` error.

    This owns the whole policy shared by the streaming and non-streaming paths: eligibility,
    preserving a more specific error already on the span, redaction, the span error payload, and
    the attachment itself. Tracing never changes what the run raises: the exception is stringified
    only when sensitive data is traced, and a formatting failure cannot propagate.
    """
    if span is None or not _is_generic_agent_error(exc):
        return

    try:
        if span.error is not None:
            return
        detail = (
            _format_agent_error_detail(exc)
            if trace_include_sensitive_data
            else REDACTED_TRACE_ERROR_MESSAGE
        )
        _error_tracing.attach_error_to_span(
            span,
            SpanError(message=GENERIC_AGENT_ERROR_MESSAGE, data={"error": detail}),
        )
    except BaseException as tracing_error:
        try:
            logger.warning(
                "Failed to record a generic agent error on the span (%s)",
                type(tracing_error).__name__,
            )
        except BaseException:
            pass


def build_run_error_data(
    *,
    input: str | list[TResponseInputItem],
    new_items: list[RunItem],
    raw_responses: list[ModelResponse],
    last_agent: Agent[Any],
    reasoning_item_id_policy: ReasoningItemIdPolicy | None = None,
) -> RunErrorData:
    history = ItemHelpers.input_to_new_input_list(input)
    output = []
    for item in new_items:
        converted = run_item_to_input_item(item, reasoning_item_id_policy)
        if converted is None:
            continue
        output.append(converted)
    history = history + list(output)
    return RunErrorData(
        input=input,
        new_items=list(new_items),
        history=history,
        output=output,
        raw_responses=list(raw_responses),
        last_agent=last_agent,
    )


def format_final_output_text(
    agent: Agent[Any],
    final_output: Any,
    *,
    data_redacted: bool = False,
) -> str:
    output_schema = get_output_schema(agent)
    if output_schema is None or output_schema.is_plain_text():
        return str(final_output)
    payload_value = final_output
    if isinstance(output_schema, AgentOutputSchema) and output_schema._is_wrapped:
        if isinstance(final_output, dict) and _WRAPPER_DICT_KEY in final_output:
            payload_value = final_output
        else:
            payload_value = {_WRAPPER_DICT_KEY: final_output}
    try:
        if isinstance(output_schema, AgentOutputSchema):
            payload_bytes = output_schema._type_adapter.dump_json(
                payload_value,
                warnings="none" if data_redacted else "warn",
            )
            return (
                payload_bytes.decode()
                if isinstance(payload_bytes, bytes | bytearray)
                else str(payload_bytes)
            )
        return json.dumps(payload_value, ensure_ascii=False)
    except (TypeError, ValueError):
        return str(final_output)


def validate_handler_final_output(
    agent: Agent[Any],
    final_output: Any,
    *,
    data_redacted: bool = False,
) -> Any:
    output_schema = get_output_schema(agent)
    if output_schema is None or output_schema.is_plain_text():
        return final_output
    payload_value = final_output
    if isinstance(output_schema, AgentOutputSchema) and output_schema._is_wrapped:
        if isinstance(final_output, dict) and _WRAPPER_DICT_KEY in final_output:
            payload_value = final_output
        else:
            payload_value = {_WRAPPER_DICT_KEY: final_output}
    try:
        if isinstance(output_schema, AgentOutputSchema):
            payload_bytes = output_schema._type_adapter.dump_json(
                payload_value,
                warnings="none" if data_redacted else "warn",
            )
            payload = (
                payload_bytes.decode()
                if isinstance(payload_bytes, bytes | bytearray)
                else str(payload_bytes)
            )
        else:
            payload = json.dumps(payload_value, ensure_ascii=False)
    except TypeError as exc:
        raise UserError("Invalid run error handler final_output for structured output.") from exc
    except ValueError as exc:
        raise UserError("Invalid run error handler final_output for structured output.") from exc
    try:
        return output_schema.validate_json(payload)
    except ModelBehaviorError as exc:
        raise UserError("Invalid run error handler final_output for structured output.") from exc


def create_message_output_item(agent: Agent[Any], output_text: str) -> MessageOutputItem:
    message = ResponseOutputMessage(
        id=FAKE_RESPONSES_ID,
        type="message",
        role="assistant",
        content=[
            ResponseOutputText(
                text=output_text,
                type="output_text",
                annotations=[],
                logprobs=[],
            )
        ],
        status="completed",
    )
    return MessageOutputItem(raw_item=message, agent=agent)


async def resolve_run_error_handler_result(
    *,
    error_handlers: RunErrorHandlers[TContext] | None,
    error_kind: RunErrorHandlerKind,
    error: MaxTurnsExceeded | ModelRefusalError | ModelBehaviorError,
    context_wrapper: RunContextWrapper[TContext],
    run_data: RunErrorData,
) -> RunErrorHandlerResult | None:
    if not error_handlers:
        return None
    handler = error_handlers.get(error_kind)
    if handler is None:
        return None
    handler_input = RunErrorHandlerInput(
        error=error,
        context=context_wrapper,
        run_data=run_data,
    )
    result = handler(handler_input)
    if inspect.isawaitable(result):
        result = await result
    if result is None:
        return None
    if isinstance(result, RunErrorHandlerResult):
        return result
    if isinstance(result, dict):
        if "final_output" in result:
            allowed_keys = {"final_output", "include_in_history"}
            extra_keys = set(result.keys()) - allowed_keys
            if extra_keys:
                raise UserError("Invalid run error handler result.")
            try:
                return RunErrorHandlerResult(**result)
            except TypeError as exc:
                raise UserError("Invalid run error handler result.") from exc
        return RunErrorHandlerResult(final_output=result)
    return RunErrorHandlerResult(final_output=result)
