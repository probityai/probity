import subprocess
import time


def test_curl_runs():
    out = subprocess.run(["curl", "--version"], capture_output=True, text=True)
    assert out.returncode == 0 and out.stdout.startswith("curl 7.")


def test_tool_reports_ok():
    time.sleep(0.5)
    out = subprocess.run(["python3", "/opt/app/tool.py"], capture_output=True, text=True)
    assert out.stdout.strip() == "ok"


def test_flag_set():
    assert open("/opt/app/flag").read().strip() == "done"
